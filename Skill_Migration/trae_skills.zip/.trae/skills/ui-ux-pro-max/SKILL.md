---
name: ui-ux-pro-max
description: UI/UX design intelligence with searchable database for web and mobile apps. Invoke when designing layouts, choosing colors/fonts, or improving UX.
---

# UI UX Pro Max

A comprehensive design intelligence system for building professional interfaces.

## Features

- **Design Systems**: Generate tailored design systems for specific domains
- **Component Patterns**: Best practices for 50+ UI components
- **Color Palettes**: 90+ accessible color combinations
- **Typography**: 50+ Google Font pairings
- **UX Guidelines**: 90+ research-backed usability rules

## Usage

### 1. Generate a Design System

Ask to generate a design system for your specific use case:

> "Generate a design system for a [Fitness App / E-commerce Site / Dashboard]"

The system will provide:
- Visual Pattern (Layout, hierarchy)
- Color Palette (Primary, secondary, semantic)
- Typography (Headings, body, pairings)
- Key Effects (Shadows, radius, transitions)
- Anti-patterns to avoid

### 2. Search for Specific Guidelines

You can search the database for specific topics:

> "Search ui-ux-pro-max for [navigation patterns]"
> "Find color palettes for [finance apps]"
> "What are the best practices for [modal dialogs]?"

### 3. Component Implementation

Get specific implementation details for your stack:

> "Show me how to implement a [Card] component in [React/Tailwind]"

## Tools

This skill includes a Python script to search the internal database:

```python
# Internal usage by the agent
python .trae/skills/ui-ux-pro-max/scripts/search.py "query string"
```
